<?php if ( !defined( 'ABSPATH' ) ) exit();

get_header( );

$id       = get_the_ID();
$avatar   = wp_get_attachment_image_url( get_post_thumbnail_id( $id ), 'large' );
$layout   = get_theme_mod('global_layout','layout_2r');

?>

<div class="row_site">
	<div class="container_site">

		<div class="service_single">
			
			<div class="content" id="main-content">
  
			    <img src="<?php echo esc_url( $avatar ) ?>" class="img-responsive service-img" alt="<?php the_title() ?>">
				
				<?php if( have_posts() ) : while( have_posts() ) : the_post();
					the_content();
		 		?>	
		 		<?php endwhile; endif; wp_reset_postdata(); ?>

		        <?php
			        if( comments_open( get_the_ID() ) ) {
			        	comments_template(); 
			        }
		        ?>
			</div>

            <?php if( $layout !== 'layout_1c') : ?>
				<div class="sidebar" id="sidebar">

					<div class="widgets">
						<?php if(is_active_sidebar('service-sidebar')){
						        dynamic_sidebar('service-sidebar');
						} ?>
					</div>

				</div>
			<?php endif; ?>
			
		</div>
		<!-- end ova_sev_single -->
	</div>
	<!-- end row -->
</div>
<!-- end container -->

<?php get_footer( );
