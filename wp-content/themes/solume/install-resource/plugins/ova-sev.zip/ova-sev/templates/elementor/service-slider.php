<?php if ( !defined( 'ABSPATH' ) ) exit();

$type           = isset( $args['type'] ) ? $args['type'] : 'horizontal' ;
$btn_class_icon = isset( $args['icon']['value'] ) ? $args['icon']['value'] : '' ;
$btn_text       = isset( $args['btn_text'] ) ? $args['btn_text'] : '' ;

$data_options['items']              = $args['item_number'];
$data_options['centerMode']         = $args['centerMode'] === 'yes' ? true : false;
$data_options['autoplayHoverPause'] = $args['pause_on_hover'] === 'yes' ? true : false;
$data_options['loop']               = $args['infinite'] === 'yes' ? true : false;
$data_options['autoplay']           = $args['autoplay'] === 'yes' ? true : false;
$data_options['autoplayTimeout']    = $args['autoplay_speed'];
$data_options['smartSpeed']         = $args['smartspeed'];
$data_options['rtl']				= is_rtl() ? true: false;

if ( $type === 'vertical') {
    $data_options['vertical']       = true;
} else {
	$data_options['vertical']       = false;
}


$sevs = ova_sev_get_services_el( $args );

?>


<div class="ova-services-slider ova-services-slider-<?php echo esc_attr($type); ?>">

	<div class="services-slider" data-options="<?php echo esc_attr( json_encode( $data_options ) ); ?>">
		<?php if( $sevs->have_posts() ) : while ( $sevs->have_posts() ) : $sevs->the_post(); 
			    $id = get_the_ID();
			    $sev_class_icon = get_post_meta( $id, 'ova_sev_met_icon', true );
			?>
			<div class="item">
				<div class="item-box">
					<i class="<?php echo esc_attr( $sev_class_icon ); ?>"></i>
					<h2 class="service-title">
						<?php the_title(); ?>		
					</h2>
				</div>
			</div>
		<?php endwhile; endif; wp_reset_postdata(); ?>
	</div>

	<div class="services-slider-content">
		<?php if( $sevs->have_posts() ) : while ( $sevs->have_posts() ) : $sevs->the_post(); 
			$id       = get_the_ID();
			$avatar   = wp_get_attachment_image_url( get_post_thumbnail_id( $id ), 'large' );

			// get category
			$categories  = wp_get_post_terms( $id, 'cat_sev' );
		?>
			<div class="content">
				<div class="content-layout">
					<?php if( !empty( $avatar ) ) :?>
						<div class="service-img">
							<img src="<?php echo esc_url( $avatar ) ?>" class="img-responsive service-img" alt="<?php the_title() ?>">
						</div>
					<?php endif; ?>
					<div class="info">
						<h2 class="service-title">
							<?php the_title(); ?>	
						</h2>
						<?php if ( ! empty( $categories ) ) { ?>
							<span class="service-category">
								<?php echo esc_html($categories[0]->name); ?>
							</span>
						<?php } ?>
						<p class="service-except">
							<?php echo get_the_excerpt(); ?>	
						</p>
						<a class="services-btn" href="<?php the_permalink(); ?>" title="<?php echo esc_attr( $btn_text ); ?>">
							<?php echo esc_html( $btn_text ); ?>
							<i class="<?php echo esc_attr( $btn_class_icon ); ?>"></i>
						</a>
					</div>
				</div>
			</div>
		<?php endwhile; endif; wp_reset_postdata(); ?>
	</div>

</div>

