<?php if ( !defined( 'ABSPATH' ) ) exit();

get_header();

?>

<div class="row_site">
	<div class="container_site">

		<div class="archive_sev">
			
			<div class="content">

				<?php if( have_posts() ) : while ( have_posts() ) : the_post(); 
                    $id       = get_the_ID();
					$avatar   = wp_get_attachment_image_url( get_post_thumbnail_id( $id ), 'large' );

					// get category
					$categories  = wp_get_post_terms( $id, 'cat_sev' );
				?>

					<div class="content-layout">
						<?php if( !empty( $avatar ) ) :?>
							<div class="service-img">
								<img src="<?php echo esc_url( $avatar ) ?>" class="img-responsive service-img" alt="<?php the_title() ?>">
							</div>
						<?php endif; ?>
						<div class="info">
							<h2 class="service-title">
								<?php the_title(); ?>	
							</h2>
							<?php if ( ! empty( $categories ) ) { ?>
								<span class="service-category">
									<?php echo esc_html($categories[0]->name); ?>
								</span>
							<?php } ?>
							<p class="service-except">
								<?php echo get_the_excerpt(); ?>	
							</p>
							<a class="services-btn" href="<?php the_permalink(); ?>" title="<?php echo esc_attr( $btn_text ); ?>">
								<?php echo esc_html_e( 'View Detail', 'ova-sev' ); ?>
								<i class="icomoon icomoon-right"></i>
							</a>
						</div>
					</div>	

				<?php endwhile; endif; wp_reset_postdata(); ?>

				<?php 
		    		$args = array(
		                'type'      => 'list',
		                'next_text' => '<i class="icomoon icomoon-angle-right"></i>',
		                'prev_text' => '<i class="icomoon icomoon-angle-left"></i>',
		            );

		            the_posts_pagination($args);
		    	 ?>

			</div>

		</div>
	</div>
</div>

<?php 
get_footer();

