<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class Ovasev_Elementor_Service_Slider extends Widget_Base {


	public function get_name() {
		return 'ovasev_elementor_service_slider';
	}

	public function get_title() {
		return esc_html__( 'Service Slider', 'ova-sev' );
	}

	public function get_icon() {
		return 'eicon-posts-grid';
	}

	public function get_categories() {
		return [ 'ovasev' ];
	}

	public function get_script_depends() {
		wp_enqueue_style( 'slick-carousel', OVASEV_PLUGIN_URI.'assets/libs/slick/slick.css' );
		wp_enqueue_style( 'slick-carousel-theme', OVASEV_PLUGIN_URI.'assets/libs/slick/slick-theme.css' );
		wp_enqueue_script( 'slick-carousel', OVASEV_PLUGIN_URI.'assets/libs/slick/slick.min.js', array('jquery'), false, true );
		return [ 'ovasev-elementor-service-slider' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__('Content', 'ova-sev' ),
			]
		);

		$args = array(
			'taxonomy' => 'cat_sev',
			'orderby' => 'name',
			'order'   => 'ASC'
		);

		$categories = get_categories($args);
		$catAll = array( 'all' => 'All categories');
		$cate_array = array();
		if ($categories) {
			foreach ( $categories as $cate ) {
				$cate_array[$cate->slug] = $cate->cat_name;
			}
		} else {
			$cate_array[] = esc_html__( "No content Category found", "ova-sev" );
		}

		$this->add_control(
			'type',
			[
				'label'   => __( 'Type', 'ova-portfolio' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'horizontal',
				'options' => [
					'horizontal' => esc_html__('Horizontal', 'ova-sev'),
					'vertical' => esc_html__('Vertical', 'ova-sev'),  
				]
			]
		);

		$this->add_control(
			'category',
			[
				'label'   => esc_html__('Category', 'ova-sev' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => array_merge( $catAll, $cate_array )
			]
		);

		$this->add_control(
			'total_count',
			[
				'label'   => esc_html__('Total', 'ova-sev' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 9
			]
		);

		$this->add_control(
			'orderby_post',
			[
				'label' => esc_html__('OrderBy Post', 'ova-sev' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'ID',
				'options' => [
					'ID'  => esc_html__('ID', 'ova-sev' ),
					'ova_sev_met_order_sev' => esc_html__('Custom Order', 'ova-sev' ),
				],
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => esc_html__( 'Icon Button', 'ova-sev' ),
				'type' => Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'icomoon icomoon-right',
					'library' 	=> 'icomoon',
				],
			]
		);

		$this->add_control(
			'btn_text',
			[
				'label' => esc_html__( 'Button Text', 'ova-sev' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'View Detail', 'ova-sev' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background_image_content_service_vertical',
				'label' => esc_html__( 'Background', 'ova-sev' ),
				'types' => [ 'classic' ],
				'selector' => '{{WRAPPER}} .ova-services-slider.ova-services-slider-vertical:before',
				'condition' => [
					'type' => 'vertical'
				]
			]
		);

		$this->end_controls_section();
        
        // Additional Options Slider
		$this->start_controls_section(
			'section_additional_options',
			[
				'label' => esc_html__( 'Additional Options', 'ova-sev' ),
			]
		);

			$this->add_control(
				'item_number',
				[
					'label'       => esc_html__( 'Item Number', 'ova-sev' ),
					'type'        => Controls_Manager::NUMBER,
					'description' => esc_html__( 'Number Item', 'ova-sev' ),
					'default'     => 6,
				]
			);

			$this->add_control(
				'centerMode',
				[
					'label'   => esc_html__( 'Center Mode', 'ova-sev' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'no',
					'options' => [
						'yes' => esc_html__( 'Yes', 'ova-sev' ),
						'no'  => esc_html__( 'No', 'ova-sev' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'pause_on_hover',
				[
					'label'   => esc_html__( 'Pause on Hover', 'ova-sev' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => esc_html__( 'Yes', 'ova-sev' ),
						'no'  => esc_html__( 'No', 'ova-sev' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'infinite',
				[
					'label'   => esc_html__( 'Infinite Loop', 'ova-sev' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => esc_html__( 'Yes', 'ova-sev' ),
						'no'  => esc_html__( 'No', 'ova-sev' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label'   => esc_html__( 'Autoplay', 'ova-sev' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => esc_html__( 'Yes', 'ova-sev' ),
						'no'  => esc_html__( 'No', 'ova-sev' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay_speed',
				[
					'label'     => esc_html__( 'Autoplay Speed', 'ova-sev' ),
					'type'      => Controls_Manager::NUMBER,
					'default'   => 5000,
					'step'      => 500,
					'condition' => [
						'autoplay' => 'yes',
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'smartspeed',
				[
					'label'   => esc_html__( 'Smart Speed', 'ova-sev' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 300,
				]
			);

		$this->end_controls_section();
        
        // Tab style
		$this->start_controls_section(
			'section_service_style',
			[
				'label' => esc_html__( 'Service', 'ova-sev' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_responsive_control(
				'service_padding',
				[
					'label' => esc_html__( 'Padding', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .ova-services-slider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'service_border_radius',
				[
					'label' => esc_html__( 'Border Radius', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .ova-services-slider' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'background_image_content_service',
					'label' => esc_html__( 'Background', 'ova-sev' ),
					'types' => [ 'classic' ],
					'selector' => '{{WRAPPER}} .ova-services-slider',
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_items_style',
			[
				'label' => esc_html__( 'Items', 'ova-sev' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'items_background',
				[
					'label' => esc_html__( 'Background', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-services-slider .services-slider .slick-slide .item .item-box' => 'background-color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'items_background_active',
				[
					'label' => esc_html__( 'Background Active', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-services-slider .services-slider .slick-slide.slick-current .item .item-box' => 'background-color: {{VALUE}}',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'item_shadow',
					'label' => esc_html__( 'Box Shadow', 'ova-sev' ),
					'selector' => '{{WRAPPER}} .ova-services-slider .services-slider .slick-slide .item .item-box',
				]
			);

			$this->add_responsive_control(
				'items_margin',
				[
					'label' => esc_html__( 'Margin', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .ova-services-slider .services-slider .slick-slide .item .item-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'items_padding',
				[
					'label' => esc_html__( 'Padding', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .ova-services-slider .services-slider .slick-slide .item .item-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'icon_options',
				[
					'label' => esc_html__( 'Icon Options', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'icon_typography',
						'selector' => '{{WRAPPER}} .ova-services-slider .services-slider .slick-slide .item .item-box i',
					]
				);

				$this->add_control(
					'icon_color',
					[
						'label' => esc_html__( 'Icon Color', 'ova-sev' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .ova-services-slider .services-slider .slick-slide .item .item-box i' => 'color: {{VALUE}}',
						],
					]
				);

				$this->add_control(
					'icon_color_active',
					[
						'label' => esc_html__( 'Icon Color Active', 'ova-sev' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .ova-services-slider .services-slider .slick-slide.slick-current .item .item-box i' => 'color: {{VALUE}}',
						],
					]
				);

				$this->add_responsive_control(
					'icon_margin',
					[
						'label' => esc_html__( 'Margin', 'ova-sev' ),
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .ova-services-slider .services-slider .slick-slide .item .item-box i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);

			$this->add_control(
				'title_options',
				[
					'label' => esc_html__( 'Title Options', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'title_typography',
						'selector' => '{{WRAPPER}} .ova-services-slider .services-slider .slick-slide .item .item-box .service-title',
					]
				);

				$this->add_control(
					'title_color',
					[
						'label' => esc_html__( 'Title Color', 'ova-sev' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .ova-services-slider .services-slider .slick-slide .item .item-box .service-title' => 'color: {{VALUE}}',
						],
					]
				);

				$this->add_control(
					'title_color_active',
					[
						'label' => esc_html__( 'Title Color Active', 'ova-sev' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .ova-services-slider .services-slider .slick-slide.slick-current .item .item-box .service-title' => 'color: {{VALUE}}',
						],
					]
				);

				$this->add_responsive_control(
					'title_margin',
					[
						'label' => esc_html__( 'Margin', 'ova-sev' ),
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .ova-services-slider .services-slider .slick-slide .item .item-box .service-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);

			$this->add_control(
				'bottom_arrow_option',
				[
					'label' => esc_html__( 'Bottom Arrow Options', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

				$this->add_control(
					'bottom_arrow_background',
					[
						'label' => esc_html__( 'Background', 'ova-sev' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .ova-services-slider .services-slider .slick-slide.slick-current:before' => 'border-top-color: {{VALUE}}',
						],
					]
				);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'ova-sev' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_responsive_control(
				'content_margin',
				[
					'label' => esc_html__( 'Margin', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .ova-services-slider .services-slider-content  .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'content_title_options',
				[
					'label' => esc_html__( 'Title Options', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'content_title_typography',
						'selector' => '{{WRAPPER}} .ova-services-slider .services-slider-content .content .content-title',
					]
				);

				$this->add_control(
					'content_title_color',
					[
						'label' => esc_html__( 'Color', 'ova-sev' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .ova-services-slider .services-slider-content .content .content-title' => 'color: {{VALUE}}',
						],
					]
				);

				$this->add_responsive_control(
					'content_title_margin',
					[
						'label' => esc_html__( 'Margin', 'ova-sev' ),
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .ova-services-slider .services-slider-content .content .content-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);

			$this->add_control(
				'content_description_options',
				[
					'label' => esc_html__( 'Description Options', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'content_description_typography',
						'selector' => '{{WRAPPER}} .ova-services-slider .services-slider-content .content .description',
					]
				);

				$this->add_control(
					'content_description_color',
					[
						'label' => esc_html__( 'Color', 'ova-sev' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .ova-services-slider .services-slider-content .content .description' => 'color: {{VALUE}}',
						],
					]
				);

				$this->add_responsive_control(
					'content_description_margin',
					[
						'label' => esc_html__( 'Margin', 'ova-sev' ),
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .ova-services-slider .services-slider-content .content .description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Button', 'ova-sev' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->start_controls_tabs(
				'style_tabs_btn'
			);

				$this->start_controls_tab(
					'style_normal_tab_btn',
					[
						'label' => esc_html__( 'Normal', 'ova-sev' ),
					]
				);

					$this->add_control(
						'btn_background',
						[
							'label' => esc_html__( 'Background', 'ova-sev' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .ova-services-slider .services-slider-content .content a.services-btn' => 'background-color: {{VALUE}}',
							],
						]
					);

					$this->add_control(
						'btn_color',
						[
							'label' => esc_html__( 'Color', 'ova-sev' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .ova-services-slider .services-slider-content .content a.services-btn' => 'color: {{VALUE}}',
							],
						]
					);

				$this->end_controls_tab();

				$this->start_controls_tab(
					'style_hover_tab_btn',
					[
						'label' => esc_html__( 'Hover', 'ova-sev' ),
					]
				);

					$this->add_control(
						'btn_background_hover',
						[
							'label' => esc_html__( 'Background', 'ova-sev' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .ova-services-slider .services-slider-content .content a.services-btn:hover' => 'background-color: {{VALUE}}',
							],
						]
					);

					$this->add_control(
						'btn_color_hover',
						[
							'label' => esc_html__( 'Color', 'ova-sev' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .ova-services-slider .services-slider-content .content a.services-btn:hover' => 'color: {{VALUE}}',
							],
						]
					);

				$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_responsive_control(
				'btn_padding',
				[
					'label' => esc_html__( 'Padding', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .ova-services-slider .services-slider-content .content a.services-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before'
				]
			);

			$this->add_responsive_control(
				'btn_margin',
				[
					'label' => esc_html__( 'Margin', 'ova-sev' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .ova-services-slider .services-slider-content .content a.services-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings();

		$template = apply_filters( 'el_ovasev_service_slider', 'elementor/service-slider.php' );

		ob_start();
		ovasev_get_template( $template, $settings );
		echo ob_get_clean();
		
	}
}
$widgets_manager->register( new Ovasev_Elementor_Service_Slider() );