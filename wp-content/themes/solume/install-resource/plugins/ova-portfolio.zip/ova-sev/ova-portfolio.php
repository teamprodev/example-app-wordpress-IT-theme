<?php
/*
Plugin Name: OvaTheme Portfolio
Plugin URI: https://themeforest.net/user/ovatheme
Description: A plugin to create Portfolio
Author: Ovatheme
Version: 1.0
Author URI: https://themeforest.net/user/ovatheme/portfolio
Text Domain: ova-portfolio
Domain Path: /languages/
*/

if ( !defined( 'ABSPATH' ) ) exit();

if ( !class_exists('OvaPortfolio') ) {
	
	class OvaPortfolio{

		function __construct() {
			$this -> define_constants();
			$this -> includes();
			$this -> supports();
		}

		function define_constants() {

			if ( !defined( 'OVAPOR_PLUGIN_FILE' ) ) {
                define( 'OVAPOR_PLUGIN_FILE', __FILE__ );   
            }

            if ( !defined( 'OVAPOR_PLUGIN_URI' ) ) {
                define( 'OVAPOR_PLUGIN_URI', plugin_dir_url( __FILE__ ) );   
            }

            if ( !defined( 'OVAPOR_PLUGIN_PATH' ) ) {
                define( 'OVAPOR_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );   
            }
			
			
			load_plugin_textdomain( 'ova-portfolio', false, basename( dirname( __FILE__ ) ) .'/languages' );
		}

		function includes() {

			// inc
			require_once( OVAPOR_PLUGIN_PATH.'inc/class-ova-custom-post-type.php' );

			require_once( OVAPOR_PLUGIN_PATH.'inc/class-ova-get-data.php' );

			require_once( OVAPOR_PLUGIN_PATH.'inc/ova-core-functions.php' );
			
			require_once( OVAPOR_PLUGIN_PATH.'inc/class-ova-templates-loaders.php' );

			require_once( OVAPOR_PLUGIN_PATH.'inc/class-ova-assets.php' );

			require_once( OVAPOR_PLUGIN_PATH.'inc/class-ajax.php' );


			// admin
			require_once( OVAPOR_PLUGIN_PATH.'admin/class-ova-metabox.php' );

			/* Customize */
			require_once OVAPOR_PLUGIN_PATH.'/inc/class-customize.php';

		}

		function supports() {

			/* Make Elementors */
			if ( did_action( 'elementor/loaded' ) ) {
				include OVAPOR_PLUGIN_PATH.'elementor/class-ova-register-elementor.php';
			}
		}

	}
}


return new OvaPortfolio();