(function($) {
    "use strict";

    $(window).on('elementor/frontend/init', function () {

        /* Menu */
        elementorFrontend.hooks.addAction('frontend/element_ready/ovapor_elementor_portfolio_filter.default', function(){
            //      
        });

    });
})(jQuery);