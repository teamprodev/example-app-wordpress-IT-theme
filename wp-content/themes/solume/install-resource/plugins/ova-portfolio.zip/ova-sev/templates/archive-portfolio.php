<?php if ( !defined( 'ABSPATH' ) ) exit();

get_header();

$type = isset( $_GET['archive_type_portfolio'] ) ? sanitize_text_field( $_GET['archive_type_portfolio'] ) : '';

$type = $type != '' ? $type : get_theme_mod( 'ova_portfolio_layout', 'filter' );

if( $type == 'grid' ){
    ovapor_get_template( 'archive-portfolio-grid.php' );
}else if( $type == 'masonry' ) {
    ovapor_get_template( 'archive-portfolio-masonry.php' );
} else if( $type == 'masonry_2' ) {
    ovapor_get_template( 'archive-portfolio-masonry-2.php' );
}

get_footer();