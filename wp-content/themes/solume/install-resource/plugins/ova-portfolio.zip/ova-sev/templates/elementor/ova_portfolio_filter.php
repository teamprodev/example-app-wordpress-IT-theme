<?php

if ( ! defined( 'ABSPATH' ) ) exit;

$number_column  = $args['number_column'];
$portfolios     = ovapor_get_data_portfolio_el( $args );

$por_args = array(
   'taxonomy' => 'category_portfolio',
   'orderby' => 'name',
   'order'   => 'ASC'
	);

$catAll = esc_html__('All', 'ova-portfolio') ;
$categories = get_categories($por_args);

?>

<div class="ova-portfolio">

	<ul class="portfolio-filter-button-wrapper">

		<li class="portfolio-filter-button active-category" data-filter="*">
			<?php echo esc_html( $catAll ); ?>
		</li>

		<?php foreach ( $categories as $cate ) : 
			$name = $cate->name;
			$slug = $cate->slug;
		?>
            <li class="portfolio-filter-button" data-slug=".<?php echo esc_attr($slug);?>">
            	<?php echo esc_html( $name ); ?>
            </li>
        <?php endforeach; ?>

	</ul>	

	<div class="content-por grid-portfolio <?php echo esc_attr( $number_column ) ?>">

		<?php if($portfolios->have_posts() ) : while ( $portfolios->have_posts() ) : $portfolios->the_post(); ?>

			<?php 
			   if( $args['template'] === 'template1' ) {
			      ovapor_get_template( 'parts/item-portfolio1.php', $args );
			   } elseif( $args['template'] === 'template2' ) {
			    	ovapor_get_template( 'parts/item-portfolio2.php', $args );
			   } elseif( $args['template'] === 'template3' ) {
			   	ovapor_get_template( 'parts/item-portfolio3.php', $args );
			   }
			?>
			    
		<?php endwhile; endif; wp_reset_postdata(); ?>
		
	</div>

</div>