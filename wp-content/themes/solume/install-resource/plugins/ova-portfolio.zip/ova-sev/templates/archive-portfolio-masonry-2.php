<?php if ( !defined( 'ABSPATH' ) ) exit();

$number_column = get_theme_mod( 'ova_portfolio_column_layout', 'three_column' );
$post_per_page = get_theme_mod( 'ova_portfolio_total_record', 9 );

$por_args = array(
   'taxonomy' => 'category_portfolio',
   'orderby' => 'name',
   'order'   => 'ASC'
    );

$catAll     = esc_html__('All', 'ova-portfolio') ;
$categories = get_categories($por_args);

$term_id          = get_queried_object_id();
$class_active_all = $term_id == 0 ? 'active-category' : '';

?>

<div class="row_site">
    <div class="container_site">

        <div class="ova-portfolio archive_portfolio archive_portfolio_grid">
            
            <?php if( $term_id == 0 ){ ?>
                <ul class="portfolio-filter-button-wrapper">

                    <li class="portfolio-filter-button <?php echo esc_attr( $class_active_all ) ?>" data-filter="*">
                        <?php echo esc_html( $catAll ); ?>
                    </li>

                    <?php foreach ( $categories as $cate ) : 
                        $name = $cate->name;
                        $slug = $cate->slug;
                        $class_active = ( $term_id == $cate->term_id ) ? 'active-category' : '';
                    ?>
                        <li class="portfolio-filter-button <?php echo esc_attr( $class_active ) ?>" data-slug=".<?php echo esc_attr($slug);?>">
                            <?php echo esc_html( $name ); ?>
                        </li>
                    <?php endforeach; ?>
                </ul> 
             <?php } ?>  
             
            <div class="content-por masonry-portfolio-2 <?php echo esc_attr( $number_column ) ?>">

                <?php if( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                   
                    <?php ovapor_get_template( 'parts/item-portfolio1.php', array( 'type'=> 'masonry-portfolio-2' ) ); ?>

                <?php endwhile; endif; wp_reset_postdata(); ?>
            </div>

            <!--  load more -->
            <div class="ova_more_por" data-paged="2"  data-perpage="<?php echo esc_attr($post_per_page); ?>" data-cat="<?php echo esc_attr( $term_id ) ?>" data-type="<?php echo 'masonry-portfolio-2' ?>" >
                <div class="ova-load-more-por second_font">
                    <i class="ova-loader icomoon icomoon-loading"></i>
                    <?php echo esc_html__('Load More','ova-portfolio'); ?>   
                </div>
                
                <div class="ova-nodata">
                    <?php echo esc_html__('No Data','ova-porrfolio'); ?>
                </div>
            </div>

        </div>
    </div>
</div>