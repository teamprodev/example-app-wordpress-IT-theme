<?php if ( !defined( 'ABSPATH' ) ) exit();

get_header( );

$id = get_the_ID();

$category     = get_the_terms($id, 'category_portfolio');

$list_social  = get_post_meta( $id, 'ova_portfolio_group_icon', true );
$list_info    = get_post_meta( $id, 'ova_portfolio_group_info', true );

$url_overlay  = get_post_meta( $id, 'ova_portfolio_video_overlay', true );
$video_link   = get_post_meta( $id, 'ova_portfolio_video_link', true );

$show_share_social  = get_theme_mod( 'portfolio_single_show_share_social_icon', 'yes' );

?>

   <div class="row_site">
		<div class="container_site">
			<div class="ova_portfolio_single">

				<h1 class="portfolio-title">
				    <?php the_title(); ?>
				</h1>

                <!-- Category -->
				<?php if( ! empty( $category ) ) { ?>
					<div class="portfolio-category">
						<?php 
							$arr_link = array();
							foreach( $category as $cat ) { 
						        $category_link = get_term_link($cat->term_id);
						        if ( $category_link ) {
						        	$link = '<a href="'.esc_url( $category_link ).'" title="'.esc_attr($cat->name).'">'.$cat->name.'</a>';
                                	array_push( $arr_link, $link );
						        }
							}
							if ( !empty( $arr_link ) && is_array( $arr_link ) ) {
								echo join(', ', $arr_link);
							}
						?>	
					</div>
				<?php } ?>

				<?php if( $show_share_social == 'yes' ){ ?>
		            <?php apply_filters( 'ova_share_social', get_the_permalink(), get_the_title()  ); ?>
		        <?php } ?>
	           
	           <!-- List info -->
				<?php if( ! empty( $list_info  ) ) {  ?>
					<div class="ova_portfolio_single_info">
						<?php
							foreach( $list_info  as $info ){

								$class_icon_info = isset( $info['ova_portfolio_class_icon_info'] ) ? $info['ova_portfolio_class_icon_info'] : '';
								$title_info      = isset( $info['ova_portfolio_info_title'] ) ? $info['ova_portfolio_info_title'] : '';
								$sub_title       = isset( $info['ova_portfolio_info_subtitle'] ) ? $info['ova_portfolio_info_subtitle'] : '';
								?>
								<div class="info-item">
									<i class="<?php echo esc_attr( $class_icon_info ); ?>"></i>	
									<div class="info">
										<h5 class="title">
											<?php echo esc_html( $title_info ); ?>
										</h5>
										<span class="sub-title">
											<?php echo esc_html( $sub_title ); ?>
										</span>
									</div>
								</div>
						<?php } ?>	
					</div>
				<?php } ?>

                <!-- Video -->
                <?php if( ( $url_overlay != '' ) && ( $video_link != '' )  ) : ?>
	                <div class="portfolio-video">
	                	<div class="ova-video-container">
				        	<img src="<?php echo esc_url( $url_overlay ) ?>" alt="<?php the_title(); ?>">
				        	<div class="video-content video-btn" id="ova-portfolio-video" 
								 data-src="<?php echo esc_url( $video_link ); ?>">
								<i class="icomoon icomoon-media"></i>
							</div>
				        </div>
		                
				        <div class="portfolio-modal-container">
							<div class="modal">
								<i class="ovaicon-cancel"></i>
								<iframe class="modal-video" allow="autoplay"></iframe>
							</div>
					    </div>
	                </div>
	            <?php endif; ?>
                
                <!-- Main Content -->
				<div class="ova_portfolio_single_main_content">
					
                    <!-- Block -->
					<div class="ova_portfolio_single_description">
						<?php if( have_posts() ) : while( have_posts() ) : the_post();
							the_content();
							?>
						<?php endwhile; endif; wp_reset_postdata(); ?>
					</div>

					<!-- Next Preview Post -->
				    <div class="ova-next-pre-post">
						<?php
						$prev_post = get_previous_post();
						$next_post = get_next_post();
						?>
						
						<?php
						if($prev_post) {
							?>
							<a class="pre" href="<?php echo esc_attr(get_permalink($prev_post->ID)); ?>">
								<span class="num-1">
									<i class="icomoon icomoon-angle-left"></i>
								</span>
								<span  class="num-2">
									<span class="second_font text-label"><?php esc_html_e('Previous Post', 'solume'); ?></span>
									<span  class="second_font title" ><?php echo esc_html(get_the_title($prev_post->ID)); ?></span>
								</span>
							</a>

							<?php
						}

						?>		
						
						<?php
						if($next_post) {
							?>
							<a class="next" href="<?php echo esc_attr(get_permalink($next_post->ID)); ?> ">
								<span class="num-1">
									<i class="icomoon icomoon-angle-right"></i>
								</span>
								<span  class="num-2">
									<span class="second_font text-label"><?php esc_html_e('Next Post', 'solume'); ?></span>
									<span class="second_font title" ><?php echo esc_html(get_the_title($next_post->ID)); ?></span>
								</span>
							</a>
							<?php
						}
						?>
					</div>

					<?php if ( comments_open() || get_comments_number() ) {
				    	comments_template();
				    }
				    ?>
			    </div>

			</div>
		</div>
	</div>

<?php get_footer( );
