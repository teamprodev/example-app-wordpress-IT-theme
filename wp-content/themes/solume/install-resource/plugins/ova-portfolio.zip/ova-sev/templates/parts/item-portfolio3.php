<?php if ( !defined( 'ABSPATH' ) ) exit();

	if ( isset( $args['id'] ) && $args['id'] ) {
		$id = $args['id'];
	} else {
		$id = get_the_id();
	}

	$category     = get_the_terms($id, 'category_portfolio');
	$type         = isset( $args['type'] ) ?  $args['type'] : '';
	
	// get size portfolio image by type layout
    if ( $type == '' || $type == 'grid-portfolio' ) {
        $avatar   = wp_get_attachment_image_url( get_post_thumbnail_id( $id ), 'solume_portfolio_thumbnail' ); 
	} elseif( $type == 'masonry-portfolio-2') {
        $avatar   = wp_get_attachment_image_url( get_post_thumbnail_id( $id ), 'large' );
	} elseif( $type == 'masonry-portfolio') {
        $avatar   = wp_get_attachment_image_url( get_post_thumbnail_id( $id ), 'solume_portfolio_fixed_width' );
	}

	if ( $avatar == '') {
        $avatar   =  get_template_directory_uri() . '/assets/img/placeholder-image.jpg';
	}
	
	$show_link_to = isset( $args['show_link_to_detail'] ) ? $args['show_link_to_detail'] : 'yes' ;
	$cat_slug     = get_cat_slug_por_by_id_por( $id );

?>

<div class="ovapor-item item-portfolio3 <?php echo esc_attr($cat_slug);?>">

	<div class="img-portfolio">
		
		<!-- Image -->
		<?php if( $show_link_to == 'yes' ): ?>
	    <a href="<?php the_permalink(); ?>" >
	    <?php endif; ?>	
	    	<img src="<?php echo esc_url( $avatar ) ?>" class="img-responsive portfolio-img" alt="<?php the_title() ?>">
			<div class="mask"></div>
			<!-- Info -->
			<div class="info">
                <div class="icon">
					<i class="icomoon icomoon-view"></i>
				</div>
				
				<!-- Category -->
				<?php if( ! empty( $category ) ) { ?>
					<div class="portfolio-category">
						<?php 
							$arr_link = array();
							foreach( $category as $cat ) { 
						        $category_link = get_term_link($cat->term_id);
						        if ( $category_link ) {
						        	$link = '<a href="'.esc_url( $category_link ).'" title="'.esc_attr($cat->name).'">'.$cat->name.'</a>';
		                        	array_push( $arr_link, $link );
						        }
							}
							if ( !empty( $arr_link ) && is_array( $arr_link ) ) {
								echo join(', ', $arr_link);
							}
						?>	
					</div>
				<?php } ?>

				<h3 class="name">
					<?php the_title(); ?>
				</h3>

			</div>
	    <?php if( $show_link_to == 'yes' ): ?>
		</a>
		<?php endif; ?>	

	</div>

</div>