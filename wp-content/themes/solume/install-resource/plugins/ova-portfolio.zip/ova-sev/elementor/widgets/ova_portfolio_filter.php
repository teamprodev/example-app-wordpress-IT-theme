<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Ovapor_Elementor_Portfolio_Filter extends Widget_Base {

	public function get_name() {
		return 'ovapor_elementor_portfolio_filter';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Filter', 'ova-portfolio' );
	}

	public function get_icon() {
		return 'eicon-archive';
	}

	public function get_categories() {
		return [ 'ovapor' ];
	}

	public function get_script_depends() {
		return [ 'ovapor-elementor-portfolio-filter' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'ova-portfolio' ),
			]
		);	


			$this->add_control(
				'template',
				[
					'label'   => __( 'Template', 'ova-portfolio' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'template1',
					'options' => [
						'template1' => esc_html__('Template 1', 'ova-portfolio'),
						'template2' => esc_html__('Template 2', 'ova-portfolio'),
						'template3' => esc_html__('Template 3', 'ova-portfolio'),    
					]
				]
			);

			// Add Class control

			$this->add_control(
				'total_count',
				[
					'label'   => __( 'Total', 'ova-portfolio' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 6
				]
			);

			$this->add_control(
				'number_column',
				[
					'label' => __( 'Number Of Column', 'ova-portfolio' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'three_column',
					'options' => [
						'two_column'      => __( '2 Columns', 'ova-portfolio' ),
						'three_column' => __( '3 Columns', 'ova-portfolio' ),
						'four_column'      => __( '4 Columns', 'ova-portfolio' ),
					],
				]
			);

			$this->add_control(
				'orderby_post',
				[
					'label' => __( 'OrderBy Post', 'ova-portfolio' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'ID',
					'options' => [
						'ID'  => __( 'ID', 'ova-portfolio' ),
						'title'  => __( 'Title', 'ova-portfolio' ),
					],
				]
			);

			$this->add_control(
				'order',
				[
					'label' => __( 'Order', 'ova-portfolio' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'ASC',
					'options' => [
						'ASC'  => __( 'Ascending', 'ova-portfolio' ),
						'DESC'  => __( 'Descending', 'ova-portfolio' ),
					],
				]
			);

			$this->add_control(
				'offset',
				[
					'label'   => __( 'Offset', 'ova-portfolio' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 0
				]
			);

			$this->add_control(
				'show_link_to_detail',
				[
					'label' => __( 'Show Link to Detail', 'ova-portfolio' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'ova-portfolio' ),
					'label_off' => __( 'Hide', 'ova-portfolio' ),
					'return_value' => 'yes',
					'default' => 'yes',
				]
			);

		$this->end_controls_section();

		/* Begin Category Filter Style */
		$this->start_controls_section(
            'filter_style',
            [
                'label' => esc_html__( 'Filter', 'ova-portfolio' ),
                'tab' 	=> Controls_Manager::TAB_STYLE,
            ]
        );

        	$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 	=> 'filter_typography',
					'selector' 	=> '{{WRAPPER}} .ova-portfolio .portfolio-filter-button-wrapper li.portfolio-filter-button',	
				]
			);

			$this->add_control(
	            'filter_color_normal',
	            [
	                'label' 	=> esc_html__( 'Color', 'ova-portfolio' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'selectors' => [
	                    '{{WRAPPER}} .ova-portfolio .portfolio-filter-button-wrapper li.portfolio-filter-button' => 'color: {{VALUE}}',
	                ],
	            ]
	        );

			$this->add_control(
	            'filter_color_active',
	            [
	                'label' 	=> esc_html__( 'Color Active', 'ova-portfolio' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'selectors' => [
	                    '{{WRAPPER}} .ova-portfolio .portfolio-filter-button-wrapper li.portfolio-filter-button.active-category' => 'color: {{VALUE}}',
	                ],
	            ]
	        );

	        $this->add_control(
	            'filter_underline_color_normal',
	            [
	                'label' 	=> esc_html__( 'Underline Active Color', 'ova-portfolio' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'selectors' => [
	                    '{{WRAPPER}} .ova-portfolio .portfolio-filter-button-wrapper li.portfolio-filter-button.active-category:before' => 'background-color: {{VALUE}}',
	                ],
	            ]
	        );

	        $this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'border_filter_active',
					'label' => esc_html__( 'Border', 'ova-portfolio' ),
					'selector' => '{{WRAPPER}} .ova-portfolio .portfolio-filter-button-wrapper li.portfolio-filter-button.active-category',
				]
			);

			$this->add_responsive_control(
	            'filter_padding',
	            [
	                'label' 		=> esc_html__( 'Padding', 'ova-portfolio' ),
	                'type' 			=> Controls_Manager::DIMENSIONS,
	                'size_units' 	=> [ 'px', '%', 'em' ],
	                'selectors' 	=> [
	                    '{{WRAPPER}} .ova-portfolio .portfolio-filter-button-wrapper li.portfolio-filter-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

	        $this->add_responsive_control(
	            'filter_margin',
	            [
	                'label' 		=> esc_html__( 'Margin', 'ova-portfolio' ),
	                'type' 			=> Controls_Manager::DIMENSIONS,
	                'size_units' 	=> [ 'px', '%', 'em' ],
	                'selectors' 	=> [
	                    '{{WRAPPER}} .ova-portfolio .portfolio-filter-button-wrapper li.portfolio-filter-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

        $this->end_controls_section();
        /* End Filter Style */

		/* Begin Image Style */
		$this->start_controls_section(
			'section_image',
			[
				'label' => esc_html__( 'Image', 'ova-portfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_responsive_control(
				'image_min_height',
				[
					'label' 		=> esc_html__( 'Min Height', 'ova-portfolio' ),
					'type' 			=> Controls_Manager::SLIDER,
					'size_units' 	=> [ 'px'],
					'range' => [
						'px' => [
							'min' => 300,
							'max' => 500,
							'step' => 10,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-portfolio .ovapor-item .img-portfolio img' => 'min-height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
	            'overlay_bgcolor',
	            [
	                'label' 	=> esc_html__( 'Overlay Color', 'ova-portfolio' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'selectors' => [
	                    '{{WRAPPER}} .ova-portfolio .ovapor-item .img-portfolio .mask' => 'background-color: {{VALUE}}',
	                ],
	            ]
	        );

		$this->end_controls_section();

         /* Begin Info Style */
		$this->start_controls_section(
            'info_style',
            [
                'label' => esc_html__( 'Info', 'ova-portfolio' ),
                'tab' 	=> Controls_Manager::TAB_STYLE,
            ]
        );

			$this->add_control(
	            'info_bgcolor_normal',
	            [
	                'label' 	=> esc_html__( 'Background Color', 'ova-portfolio' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'selectors' => [
	                    '{{WRAPPER}} .ova-portfolio .ovapor-item .info' => 'background-color: {{VALUE}}',
	                ],
	            ]
	        );

			$this->add_responsive_control(
	            'info_padding',
	            [
	                'label' 		=> esc_html__( 'Padding', 'ova-portfolio' ),
	                'type' 			=> Controls_Manager::DIMENSIONS,
	                'size_units' 	=> [ 'px', '%', 'em' ],
	                'selectors' 	=> [
	                    '{{WRAPPER}} .ova-portfolio .ovapor-item .info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

	        $this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'info_box_shadow',
					'label' => esc_html__( 'Box Shadow', 'ova-portfolio' ),
					'selector' => '{{WRAPPER}} .ova-portfolio .ovapor-item .info',
				]
			);

        $this->end_controls_section();
        /* End Info Style */

		/* Begin Name Style */
		$this->start_controls_section(
            'name_style',
            [
                'label' => esc_html__( 'Name', 'ova-portfolio' ),
                'tab' 	=> Controls_Manager::TAB_STYLE,
            ]
        );

        	$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 	=> 'name_typography',
					'selector' 	=> '{{WRAPPER}} .ova-portfolio .ovapor-item .info .name',	
				]
			);

			$this->add_control(
	            'name_color_normal',
	            [
	                'label' 	=> esc_html__( 'Color', 'ova-portfolio' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'selectors' => [
	                    '{{WRAPPER}} .ova-portfolio .ovapor-item .info .name' => 'color: {{VALUE}}',
	                ],
	            ]
	        );

			$this->add_control(
	            'name_color_hover',
	            [
	                'label' 	=> esc_html__( 'Color Hover', 'ova-portfolio' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'selectors' => [
	                    '{{WRAPPER}} .ova-portfolio .ovapor-item .info .name:hover' => 'color: {{VALUE}}',
	                ],
	            ]
	        );

        $this->end_controls_section();
        /* End Name Style */

         /* Begin category Style */
		$this->start_controls_section(
            'category_section_style',
            [
                'label' => esc_html__( 'Category', 'ova-portfolio' ),
                'tab' 	=> Controls_Manager::TAB_STYLE,
            ]
        );

        	$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 	=> 'cate_typography',
					'selector' 	=> '{{WRAPPER}} .ova-portfolio .ovapor-item .info .portfolio-category',
				]
			);

			$this->add_control(
	            'cate_color_normal',
	            [
	                'label' 	=> esc_html__( 'Color', 'ova-portfolio' ),
	                'type' 		=> Controls_Manager::COLOR,
	                'selectors' => [
	                    '{{WRAPPER}} .ova-portfolio .ovapor-item .info .portfolio-category, {{WRAPPER}} .ova-portfolio .ovapor-item .info .portfolio-category a' => 'color: {{VALUE}}',
	                ],
	            ]
	        );

	        $this->add_responsive_control(
	            'cate_padding',
	            [
	                'label' 		=> esc_html__( 'Padding', 'ova-portfolio' ),
	                'type' 			=> Controls_Manager::DIMENSIONS,
	                'size_units' 	=> [ 'px', '%', 'em' ],
	                'selectors' 	=> [
	                    '{{WRAPPER}} .ova-portfolio .ovapor-item .info .portfolio-category' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

        $this->end_controls_section();
        /* End category Style */

        /* Begin icon template1 Style */
		$this->start_controls_section(
            'icon_style_template1',
            [
                'label' => esc_html__( 'Icon', 'ova-portfolio' ),
                'tab' 	=> Controls_Manager::TAB_STYLE,
                'condition' => [
                	'template' => 'template1'
                ]
            ]
        );
            
			$this->add_responsive_control(
				'size_icon_template1',
				[
					'label' 		=> esc_html__( 'Size', 'ova-portfolio' ),
					'type' 			=> Controls_Manager::SLIDER,
					'size_units' 	=> [ 'px'],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 40,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-portfolio .item-portfolio1  .icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);
               
            $this->add_control(
				'icon_color_template1',
				[
					'label' 	=> esc_html__( 'Color', 'ova-portfolio' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-portfolio .item-portfolio1 .icon i' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'icon_bgcolor_template1',
				[
					'label' 	=> esc_html__( 'Background Color', 'ova-portfolio' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-portfolio .item-portfolio1  .icon' => 'background-color: {{VALUE}};',
					],
				]
			);

        $this->end_controls_section();
		/* End icon style */

		/* Begin icon template2 Style */
		$this->start_controls_section(
            'icon_style_template2',
            [
                'label' => esc_html__( 'Icon', 'ova-portfolio' ),
                'tab' 	=> Controls_Manager::TAB_STYLE,
                'condition' => [
                	'template' => 'template2'
                ]
            ]
        );
            
			$this->add_responsive_control(
				'size_icon_template2',
				[
					'label' 		=> esc_html__( 'Size', 'ova-portfolio' ),
					'type' 			=> Controls_Manager::SLIDER,
					'size_units' 	=> [ 'px'],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 40,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-portfolio .item-portfolio2 .img-portfolio .icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);
               
            $this->add_control(
				'icon_color_template2',
				[
					'label' 	=> esc_html__( 'Color', 'ova-portfolio' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-portfolio .item-portfolio2 .img-portfolio .icon i' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'icon_bgcolor_template2',
				[
					'label' 	=> esc_html__( 'Background Color', 'ova-portfolio' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova-portfolio .item-portfolio2 .img-portfolio .icon' => 'background-color: {{VALUE}};',
					],
				]
			);

        $this->end_controls_section();
		/* End icon style */

	}


	protected function render() {

		$settings = $this->get_settings();

		$template = apply_filters( 'el_ovapor_portfolio_filter', 'elementor/ova_portfolio_filter.php' );

		ob_start();
		ovapor_get_template( $template, $settings );
		echo ob_get_clean();
		
	}
}

$widgets_manager->register( new Ovapor_Elementor_Portfolio_Filter() );
