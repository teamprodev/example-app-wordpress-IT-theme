<?php

if ( !defined( 'ABSPATH' ) ) exit();

add_action( 'cmb2_init', 'ova_portfolio_metaboxes' );
function ova_portfolio_metaboxes() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = 'ova_portfolio_';
    
    /* Portfolio Settings */
    $portfolio_settings = new_cmb2_box( array(
        'id'            => 'ovaportfolio_settings',
        'title'         => esc_html__( 'Settings', 'ova-portfolio' ),
        'object_types'  => array( 'ova_portfolio'), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
        
    ) );


    // Info
    $group_info = $portfolio_settings->add_field( array(
        'id'          => $prefix . 'group_info',
        'type'        => 'group',
        'description' => esc_html__( 'Info', 'ova-portfolio' ),
        'options'     => array(
            'group_title'       => esc_html__( 'Info', 'ova-portfolio' ), 
            'add_button'        => esc_html__( 'Add Info', 'ova-portfolio' ),
            'remove_button'     => esc_html__( 'Remove', 'ova-portfolio' ),
            'sortable'          => true,
           
        ),
    ) );

    $portfolio_settings->add_group_field( $group_info, array(
        'name' => esc_html__( 'Class icon info', 'ova-portfolio' ),
        'id'   => $prefix . 'class_icon_info',
        'type' => 'text',
    ) );


    $portfolio_settings->add_group_field( $group_info, array(
        'name' => esc_html__( 'Title', 'ova-portfolio' ),
        'id'   => $prefix . 'info_title',
        'type' => 'text',
    ) );

    $portfolio_settings->add_group_field( $group_info, array(
        'name' => esc_html__( 'Sub Title', 'ova-portfolio' ),
        'id'   => $prefix . 'info_subtitle',
        'type' => 'text',
    ) );

    // Video Overlay
    $portfolio_settings->add_field( array(
        'name'       => esc_html__( 'Video Overlay Image', 'ova-portfolio' ),
        'id'         => $prefix . 'video_overlay',
        'type'    => 'file',
        'query_args' => array(
            'type' => array(
                'image/gif',
                'image/jpeg',
                'image/png',
            ),
        ),
    ) );

    $portfolio_settings->add_field( array(
        'name'       => esc_html__( 'Video Link', 'ova-portfolio' ),
        'id'         => $prefix . 'video_link',
        'type'    => 'text_url',
    ) );

}
