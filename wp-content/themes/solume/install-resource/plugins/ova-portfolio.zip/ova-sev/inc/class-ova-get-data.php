<?php

if ( !defined( 'ABSPATH' ) ) exit();

// The query portfolio
add_action( 'pre_get_posts', 'ovapor_post_per_page_archive' );
function ovapor_post_per_page_archive( $query ) {

	if ( ( is_post_type_archive( 'ova_portfolio' )  && !is_admin() )  || ( is_tax('category_portfolio') && !is_admin() ) ) {

		if ( $query->is_post_type_archive( 'ova_portfolio' ) || $query->is_tax('category_portfolio') ) {
			$query->set('post_type', array( 'ova_portfolio' ) );
			$query->set('posts_per_page', get_theme_mod( 'ova_portfolio_total_record', 8 ) );
			$query->set('orderby', 'meta_value_num' );
            $query->set('order', 'ASC' );
            $query->set('meta_type', 'NUMERIC' );
		}
	}
}

function ovapor_get_data_portfolio_el( $args ){

	$args_new = array(
		'post_type' => 'ova_portfolio',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
		'offset' => $args['offset'],
		'fields' => 'ids',
	);

	$args_portfolio_order = [];
	
	$args_portfolio_order = [
		'orderby' => $args['orderby_post'],
		'order'   => $args['order'],
	];

	$args_portfolio = array_merge( $args_new, $args_portfolio_order );

	$portfolios  = new \WP_Query($args_portfolio);

	return $portfolios;

}

function get_cat_slug_por_by_id_por( $id_por = '' ){

	if( $id_por === '' ) return;

	$cat_pors = get_the_terms( $id_por, 'category_portfolio' );
	$i = 0;

	$cat_slug = '';
	if( ! empty( $cat_pors ) ){
		$count_cat = count( $cat_pors );
		?>
		<?php
		foreach ($cat_pors as $cat_por) {
			$i++;
			$separator = ( $count_cat !== $i ) ? " " : "";

			$term_slug = $cat_por->slug;

			$cat_slug .= $term_slug . $separator;
		}
	}

	return $cat_slug;
}