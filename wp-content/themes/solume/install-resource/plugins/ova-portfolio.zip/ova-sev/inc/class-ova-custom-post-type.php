<?php 

if ( !defined( 'ABSPATH' ) ) exit();

if ( !class_exists( 'OVAPOR_custom_post_type' ) ) {

	class OVAPOR_custom_post_type{

		public function __construct(){
			add_action( 'init', array( $this, 'OVAPOR_register_post_type_portfolio' ) );
			add_action( 'init', array( $this, 'OVAPOR_register_taxonomy_portfolio' ) );
		}

		function OVAPOR_register_post_type_portfolio() {

			$labels = array(
				'name'                  => _x( 'Portfolios', 'Post Type General Name', 'ova-portfolio' ),
				'singular_name'         => _x( 'Portfolio', 'Post Type Singular Name', 'ova-portfolio' ),
				'menu_name'             => esc_html__( 'Portfolios', 'ova-portfolio' ),
				'name_admin_bar'        => esc_html__( 'Post Type', 'ova-portfolio' ),
				'archives'              => esc_html__( 'Item Archives', 'ova-portfolio' ),
				'attributes'            => esc_html__( 'Item Attributes', 'ova-portfolio' ),
				'parent_item_colon'     => esc_html__( 'Parent Item:', 'ova-portfolio' ),
				'all_items'             => esc_html__( 'All Portfolios', 'ova-portfolio' ),
				'add_new_item'          => esc_html__( 'Add New Portfolio', 'ova-portfolio' ),
				'add_new'               => esc_html__( 'Add New', 'ova-portfolio' ),
				'new_item'              => esc_html__( 'New Item', 'ova-portfolio' ),
				'edit_item'             => esc_html__( 'Edit', 'ova-portfolio' ),
				'view_item'             => esc_html__( 'View Item', 'ova-portfolio' ),
				'view_items'            => esc_html__( 'View Items', 'ova-portfolio' ),
				'search_items'          => esc_html__( 'Search Item', 'ova-portfolio' ),
				'not_found'             => esc_html__( 'Not found', 'ova-portfolio' ),
				'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'ova-portfolio' ),
			);

			$args = array(
				'description'         => esc_html__( 'Post Type Description', 'ova-portfolio' ),
				'labels'              => $labels,
				'supports'            => array( 'title', 'editor', 'thumbnail', 'comments' ),
				'hierarchical'        => false,
				'public'              => true,
				'show_ui'             => true,
				'menu_position'       => 5,
				'query_var'           => true,
				'has_archive'         => true,
				'exclude_from_search' => true,
				'publicly_queryable'  => true,
				'rewrite'             => array( 'slug' => _x( 'portfolio', 'URL slug', 'ova-portfolio' ) ),
				'capability_type'     => 'post',
				'show_in_rest'        => true,
				'menu_icon'           => 'dashicons-portfolio'
			);

			register_post_type( 'ova_portfolio', $args );
		}

		function OVAPOR_register_taxonomy_portfolio(){
			
			$labels = array(
				'name'                       => _x( 'Category Portfolio', 'Post Type General Name', 'ova-portfolio' ),
				'singular_name'              => _x( 'Category Portfolio', 'Post Type Singular Name', 'ova-portfolio' ),
				'menu_name'                  => esc_html__( 'Category', 'ova-portfolio' ),
				'all_items'                  => esc_html__( 'All Category Portfolio', 'ova-portfolio' ),
				'parent_item'                => esc_html__( 'Parent Item', 'ova-portfolio' ),
				'parent_item_colon'          => esc_html__( 'Parent Item:', 'ova-portfolio' ),
				'new_item_name'              => esc_html__( 'New Item Name', 'ova-portfolio' ),
				'add_new_item'               => esc_html__( 'Add New Category Portfolio', 'ova-portfolio' ),
				'add_new'                    => esc_html__( 'Add New Category Portfolio', 'ova-portfolio' ),
				'edit_item'                  => esc_html__( 'Edit Category Portfolio', 'ova-portfolio' ),
				'view_item'                  => esc_html__( 'View Item', 'ova-portfolio' ),
				'separate_items_with_commas' => esc_html__( 'Separate items with commas', 'ova-portfolio' ),
				'add_or_remove_items'        => esc_html__( 'Add or remove items', 'ova-portfolio' ),
				'choose_from_most_used'      => esc_html__( 'Choose from the most used', 'ova-portfolio' ),
				'popular_items'              => esc_html__( 'Popular Items', 'ova-portfolio' ),
				'search_items'               => esc_html__( 'Search Items', 'ova-portfolio' ),
				'not_found'                  => esc_html__( 'Not Found', 'ova-portfolio' ),
				'no_terms'                   => esc_html__( 'No items', 'ova-portfolio' ),
				'items_list'                 => esc_html__( 'Items list', 'ova-portfolio' ),
				'items_list_navigation'      => esc_html__( 'Items list navigation', 'ova-portfolio' ),

			);

			$args = array(
				'labels'            	=> $labels,
				'hierarchical'      	=> true,
				'publicly_queryable' 	=> true,
				'public'            	=> true,
				'show_ui'           	=> true,
				'show_admin_column' 	=> true,
				'show_in_nav_menus' 	=> true,
				'show_tagcloud'     	=> false,
				'show_in_rest'        	=> true,
				'rewrite'            	=> array(
					'slug'       => _x( 'category_portfolio', 'Category Portfolio Slug', 'ova-portfolio' ),
					'with_front' => false,
					'feeds'      => true,
				),
			);
			
			register_taxonomy( 'category_portfolio', array( 'ova_portfolio' ), $args );
		}
	}

	new OVAPOR_custom_post_type();
}