<?php

if ( !defined( 'ABSPATH' ) ) exit();

if ( !class_exists( 'Ova_Portfolio_Customize' ) ) {

	class Ova_Portfolio_Customize {

		public function __construct() {
			add_action( 'customize_register', array( $this, 'ova_portfolio_customize_register' ) );
		}

		public function ova_portfolio_customize_register( $wp_customize ) {

			$this->ova_portfolio_init( $wp_customize );

			do_action( 'ova_portfolio_customize_register', $wp_customize );
		}


		/* Portfolio */
		public function ova_portfolio_init( $wp_customize ){

			$wp_customize->add_panel( 'ova_portfolio_section' , array(
				'title'      => esc_html__( 'Portfolio', 'ova-portfolio' ),
				'priority'   => 5
			) );

				// Archive
				$wp_customize->add_section( 'ova_portfolio_archive_section' , array(
				    'title'     => esc_html__( 'Archive', 'ova-portfolio' ),
				    'priority'  => 1,
				    'panel' 	=> 'ova_portfolio_section'
				) );
					
					// Post per page
					$wp_customize->add_setting( 'ova_portfolio_total_record', array(
						  'type' 				=> 'theme_mod', // or 'option'
						  'capability' 			=> 'edit_theme_options',
						  'theme_supports' 		=> '', // Rarely needed.
						  'default' 			=> '9',
						  'transport' 			=> 'refresh', // or postMessage
						  'sanitize_callback' 	=> 'sanitize_text_field' // Get function name 
						  
					) );
					
					$wp_customize->add_control('ova_portfolio_total_record', array(
						'label' 	=> esc_html__('Number of posts per page','ova-portfolio'),
						'section' 	=> 'ova_portfolio_archive_section',
						'settings' 	=> 'ova_portfolio_total_record',
						'type' 		=> 'number'
					));

					// Layout
					$wp_customize->add_setting( 'ova_portfolio_layout', array(
						'type' 				=> 'theme_mod', // or 'option'
						'capability' 		=> 'edit_theme_options',
						'theme_supports' 	=> '', // Rarely needed.
						'default' 			=> 'grid',
						'transport' 		=> 'refresh', // or postMessage
						'sanitize_callback' => 'sanitize_text_field' // Get function name 
					) );

					$wp_customize->add_control('ova_portfolio_layout', array(
						'label' 	=> esc_html__('Type','ova-portfolio'),
						'section' 	=> 'ova_portfolio_archive_section',
						'settings' 	=> 'ova_portfolio_layout',
						'type' 		=>'select',
						'choices' 	=> array(
							'grid'   	=> esc_html__( 'Grid', 'ova-portfolio' ),
							'masonry'   => esc_html__( 'Masonry 1', 'ova-portfolio' ),
							'masonry_2'  	=> esc_html__( 'Masonry 2', 'ova-portfolio' )
						)
					));
                    
                    // Column Layout
					$wp_customize->add_setting( 'ova_portfolio_column_layout', array(
					  'type' => 'theme_mod', // or 'option'
					  'capability' => 'edit_theme_options',
					  'theme_supports' => '', // Rarely needed.
					  'default' => 'three_column',
					  'transport' => 'refresh', // or postMessage
					  'sanitize_callback' => 'sanitize_text_field' // Get function name 
					  
					) );

					$wp_customize->add_control('ova_portfolio_column_layout', array(
						'label' => esc_html__('Column','ova-portfolio'),
						'section' => 'ova_portfolio_archive_section',
						'settings' => 'ova_portfolio_column_layout',
						'type' =>'select',
						'choices' => array(
							'two_column'      => __( '2 column', 'ova-portfolio' ),
							'three_column' => __( '3 column', 'ova-portfolio' ),
							'four_column'      => __( '4 column', 'ova-portfolio' ),
						)
					));

					// Header Archive Portfolio
					$wp_customize->add_setting( 'header_archive_portfolio', array(
						'type' 				=> 'theme_mod', // or 'option'
						'capability' 		=> 'edit_theme_options',
						'theme_supports' 	=> '', // Rarely needed.
						'default' 			=> 'default',
						'transport' 		=> 'refresh', // or postMessage
						'sanitize_callback' => 'sanitize_text_field' // Get function name 
					) );

					$wp_customize->add_control('header_archive_portfolio', array(
						'label' 	=> esc_html__('Header Archive','ova-portfolio'),
						'section' 	=> 'ova_portfolio_archive_section',
						'settings' 	=> 'header_archive_portfolio',
						'type' 		=>'select',
						'choices' 	=> apply_filters( 'solume_list_header', '' )
					));

					// Footer Archive Portfolio
					$wp_customize->add_setting( 'footer_archive_portfolio', array(
						'type' 				=> 'theme_mod', // or 'option'
						'capability' 		=> 'edit_theme_options',
						'theme_supports' 	=> '', // Rarely needed.
						'default' 			=> 'default',
						'transport' 		=> 'refresh', // or postMessage
						'sanitize_callback' => 'sanitize_text_field' // Get function name 
					) );

					$wp_customize->add_control('footer_archive_portfolio', array(
						'label' 	=> esc_html__('Footer Archive','ova-portfolio'),
						'section' 	=> 'ova_portfolio_archive_section',
						'settings' 	=> 'footer_archive_portfolio',
						'type' 		=>'select',
						'choices' 	=> apply_filters('solume_list_footer', '')
					));

				// Single
				$wp_customize->add_section( 'ova_portfolio_single_section' , array(
				    'title'     => esc_html__( 'Single', 'ova-portfolio' ),
				    'priority'  => 2,
				    'panel' 	=> 'ova_portfolio_section',
				) );
                    
                    // Share social icon
				    $wp_customize->add_setting( 'portfolio_single_show_share_social_icon', array(
					  'type' => 'theme_mod', // or 'option'
					  'capability' => 'edit_theme_options',
					  'theme_supports' => '', // Rarely needed.
					  'default' => 'yes',
					  'transport' => 'refresh', // or postMessage
					  'sanitize_callback' => 'sanitize_text_field' // Get function name 
					  
					) );
					
					$wp_customize->add_control('portfolio_single_show_share_social_icon', array(
						'label' => esc_html__('Show Share Social Icon','solume'),
						'section' => 'ova_portfolio_single_section',
						'settings' => 'portfolio_single_show_share_social_icon',
						'type' =>'select',
						'choices' => array(
							'yes' => esc_html__('Yes', 'solume'),
							'no'		=> esc_html__('No', 'solume'),
						)
					));

					// Header Single Portfolio
					$wp_customize->add_setting( 'header_single_portfolio', array(
						'type' 				=> 'theme_mod', // or 'option'
						'capability' 		=> 'edit_theme_options',
						'theme_supports' 	=> '', // Rarely needed.
						'default' 			=> 'default',
						'transport' 		=> 'refresh', // or postMessage
						'sanitize_callback' => 'sanitize_text_field' // Get function name 
					) );

					$wp_customize->add_control('header_single_portfolio', array(
						'label' 	=> esc_html__('Header Single','ova-portfolio'),
						'section' 	=> 'ova_portfolio_single_section',
						'settings' 	=> 'header_single_portfolio',
						'type' 		=>'select',
						'choices' 	=> apply_filters( 'solume_list_header', '' )
					));

					// Footer Single Portfolio
					$wp_customize->add_setting( 'footer_single_portfolio', array(
						'type' 				=> 'theme_mod', // or 'option'
						'capability' 		=> 'edit_theme_options',
						'theme_supports' 	=> '', // Rarely needed.
						'default' 			=> 'default',
						'transport' 		=> 'refresh', // or postMessage
						'sanitize_callback' => 'sanitize_text_field' // Get function name 
					) );

					$wp_customize->add_control('footer_single_portfolio', array(
						'label' 	=> esc_html__('Footer Single','ova-portfolio'),
						'section' 	=> 'ova_portfolio_single_section',
						'settings' 	=> 'footer_single_portfolio',
						'type' 		=>'select',
						'choices' 	=> apply_filters('solume_list_footer', '')
					));

					// Add customize
		}

	}

	new Ova_Portfolio_Customize();
}