<?php

if ( !defined( 'ABSPATH' ) ) exit();

if( !function_exists( 'ovapor_locate_template' ) ){
	function ovapor_locate_template( $template_name, $template_path = '', $default_path = '' ) {
		
		// Set variable to search in ovacoll-templates folder of theme.
		if ( ! $template_path ) {
			$template_path = 'ovaportfolio-templates/';
		}

		// Set default plugin templates path.
		if ( ! $default_path ) {
			$default_path = OVAPOR_PLUGIN_PATH . 'templates/'; // Path to the template folder
		}

		// Search template file in theme folder.
		$template = locate_template( array( $template_path . $template_name ) );

		// Get plugins template file.
		if ( ! $template ) {
			$template = $default_path . $template_name;
		}

		return apply_filters( 'ovapor_locate_template', $template, $template_name, $template_path, $default_path );
	}
}

function ovapor_get_template( $template_name, $args = array(), $tempate_path = '', $default_path = '' ) {
	if ( is_array( $args ) && isset( $args ) ) :
		extract( $args );
	endif;
	$template_file = ovapor_locate_template( $template_name, $tempate_path, $default_path );
	if ( ! file_exists( $template_file ) ) :
		_doing_it_wrong( __FUNCTION__, sprintf( '<code>%s</code> does not exist.', $template_file ), '1.0.0' );
		return;
	endif;

	include $template_file;
}

// Get Portfolio Header
add_filter( 'solume_header_customize', 'ovapor_header_customize_portfolio', 10, 1 );
function ovapor_header_customize_portfolio( $header ){
	if ( is_tax( 'category_portfolio' ) ||  get_query_var( 'category_portfolio' ) != '' || is_post_type_archive( 'ova_portfolio' ) ) {
	  	$header = get_theme_mod( 'header_archive_portfolio', 'default' );
	} else if( is_singular( 'ova_portfolio' ) ) {
		$header = get_theme_mod( 'header_single_portfolio', 'default' );
	}

	return $header;
}

// Get Portfolio Footer
add_filter( 'solume_footer_customize', 'ovapor_footer_customize_portfolio', 10, 1 );
function ovapor_footer_customize_portfolio( $footer ){
    
   	if ( is_tax( 'category_portfolio' ) ||  get_query_var( 'category_portfolio' ) != '' || is_post_type_archive( 'ova_portfolio' ) ) {
        $footer = get_theme_mod( 'footer_archive_portfolio', 'default' );
    } else if( is_singular( 'ova_portfolio' ) ) {
        $footer = get_theme_mod( 'footer_single_portfolio', 'default' );
    }

    return $footer;

}
