<?php

if ( !defined( 'ABSPATH' ) ) exit();

if( !class_exists( 'OVAPOR_assets' ) ){
	class OVAPOR_assets{

		public function __construct(){
			add_action( 'wp_enqueue_scripts', array( $this, 'ovapor_enqueue_scripts' ), 10, 0 );
		}

		public function ovapor_enqueue_scripts(){

			// Init Css
			wp_enqueue_style( 'portfolio-style', OVAPOR_PLUGIN_URI.'assets/css/style.css' );	

			// Add JS
			wp_enqueue_script( 'script-portfolio', OVAPOR_PLUGIN_URI. 'assets/js/script.js', [ 'jquery' ], false, true );

			//Isotope
			wp_enqueue_script( 'ovapor_isotope', OVAPOR_PLUGIN_URI.'assets/libs/isotope/isotope.pkgd.min.js', array('jquery'), false, true );
			wp_enqueue_script('imagesloaded');

			// Ajax
		    $params  = array(
		    	'ajax_url' 		=> admin_url('admin-ajax.php'), 
		    	'ajax_nonce'	=> wp_create_nonce( apply_filters( 'ova_portfolio_ajax_security', 'ajax_theme' ) )
		    );
			wp_localize_script( 'script-portfolio', 'ajax_object', $params ) ;
		}

	}

	new OVAPOR_assets();
}
