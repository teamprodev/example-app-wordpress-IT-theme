<?php if ( !defined( 'ABSPATH' ) ) exit();

if ( ! class_exists( 'Ova_Portfolio_Ajax' ) ) {

	class Ova_Portfolio_Ajax{

		public function __construct(){

			add_action( 'wp_ajax_ova_loadmore_portfolio', array( $this, 'ova_loadmore_portfolio') );
			add_action( 'wp_ajax_nopriv_ova_loadmore_portfolio', array( $this, 'ova_loadmore_portfolio') );
		
		}

		public function ova_loadmore_portfolio(){

			$paged     = isset( $_POST['paged'] ) ? sanitize_text_field( $_POST['paged'] ) : 2;
			$perpage   = isset( $_POST['perpage'] ) ? sanitize_text_field( $_POST['perpage'] ) : 6;
			$cat       = isset( $_POST['cat'] ) ? sanitize_text_field( $_POST['cat'] ) : 0;
			$type      = isset( $_POST['type'] ) ? sanitize_text_field( $_POST['type'] ) : '';


			if( $cat != 0 ){
				$args = array(
				    'post_type'   => 'ova_portfolio',
				    'posts_per_page' => $perpage,
				    'paged'          => $paged,
				    'post_status' => array( 'publish' ),
				    'tax_query' => array(
				        array(
				            'taxonomy' => 'category_portfolio',
				            'field'    => 'id',
				            'terms'    => $cat, 
				        ),
				    ),
				    'orderby' => 'meta_value_num',
				    'order' => 'ASC',
				    'meta_type' => 'NUMERIC',
				);
			} else{
				$args = array(
				    'post_type'   		=> 'ova_portfolio',
				    'posts_per_page' 	=> $perpage,
				    'paged'          	=> $paged,
				    'post_status' 		=> array( 'publish' ),
				    'orderby' 			=> 'meta_value_num',
				    'order' 			=> 'ASC',
				    'meta_type' 		=> 'NUMERIC',
				);
			}
			
			$list_portfolios = new \WP_Query( $args );

			$results = '';
			ob_start();

			if( $list_portfolios->have_posts() ) : while( $list_portfolios->have_posts() ) : $list_portfolios->the_post();

				$id = get_the_ID();

	            if( $type === 'grid-portfolio') {
                    ovapor_get_template( 'parts/item-portfolio2.php', array( 'id' => $id ) );
	            } elseif( $type === 'masonry-portfolio') {
	            	ovapor_get_template( 'parts/item-portfolio1.php', array( 'id' => $id ) );
	            } elseif( $type === 'masonry-portfolio-2') {
	            	ovapor_get_template( 'parts/item-portfolio3.php', array( 'id' => $id ) );
	            }	
				   
		    endwhile; else: wp_reset_postdata(); 
		        echo 0;
		

			endif; wp_reset_postdata(); 

			$results = ob_get_contents();
			ob_end_clean();
			echo $results;

			wp_die();
	            
	    }

	
	}

	new Ova_Portfolio_Ajax();
}