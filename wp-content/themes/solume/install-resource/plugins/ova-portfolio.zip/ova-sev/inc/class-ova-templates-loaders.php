<?php

if ( !defined( 'ABSPATH' ) ) exit();

class OVAPOR_templates_loader {
	
	/**
	 * The Constructor
	 */
	public function __construct() {
		add_filter( 'template_include', array( $this, 'ovapor_template_loader' ) );
	}

	public function ovapor_template_loader( $template ) {

		$post_type 	= isset($_REQUEST['post_type'] ) ? esc_html( $_REQUEST['post_type'] ) : get_post_type();

		if ( is_tax( 'category_portfolio' ) || get_query_var( 'category_portfolio' ) != '' ) {
			$paged 		= get_query_var('paged') ? get_query_var('paged') : '1';
			query_posts( '&category_portfolio='.get_query_var( 'category_portfolio' ).'&paged=' . $paged );
			ovapor_get_template( 'archive-portfolio.php' );

			return false;
		}

		// Is Portfolio Post Type
		if (  $post_type == 'ova_portfolio' ) {

			if ( is_post_type_archive( 'ova_portfolio' ) ) {
				ovapor_get_template( 'archive-portfolio.php' );
				return false;
			} elseif ( is_single() ) {
				ovapor_get_template( 'single-portfolio.php' );
				return false;
			}
		}

		if ( $post_type !== 'ova_portfolio' ){
			return $template;
		}
	}
}

new OVAPOR_templates_loader();
